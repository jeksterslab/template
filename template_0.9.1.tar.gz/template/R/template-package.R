#' @author Ivan Jacob Agaloos Pesigan
#'
#' @title template: Title
#'
#' @description A collection of functions...
#'
#' @docType package
#' @name template
#' @keywords template package
NULL
