library(testthat)
library(template)

test_check("template")
